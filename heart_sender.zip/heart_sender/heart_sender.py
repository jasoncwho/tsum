import cv2
import numpy as np
import time
import os # Added for path management
import configparser  # Added for config file support
from ppadb.client import Client as AdbClient
from executor import SwipeExecutor

class HeartSender:
    def __init__(self, resource_folder="resource", config_file="config.ini"):
        # 1. Path Setup
        self.res_path = resource_folder
        # 2. Read Config
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        # Check the specific key (default to 'N' if not found)
        # Key 1: Send to all friends even if hearts = 0
        self.send_to_all = self.config.get('SETTINGS', 'send_to_all_fd_include_zero', fallback='N').upper() == 'Y'
        
        # Key 2: Receive all hearts (including those > 1hr)
        self.receive_all = self.config.get('SETTINGS', 'receive_all_hearts_include_gt_1_hr', fallback='N').upper() == 'Y'
        
        # ADB Connection Setup
        self.client = AdbClient(host="127.0.0.1", port=5037)
        # Target specific device to avoid "more than one device" errors
        self.device = self.client.device("emulator-5554") 
        
        if not self.device:
            print("❌ Device not found.")
            exit()

        # Initialize executor with matching device serial and unique port
        self.executor = SwipeExecutor(device_id="emulator-5554", port=1080)
        
        # Load Core Templates (Reorganized to read from resource folder)
        self.heart_tpl = self._load_tpl("heart.PNG")
        self.ok_tpl = self._load_tpl("ok_button.PNG")
        self.zero_tpl = self._load_tpl("zero.PNG")
        self.coin_tpl = self._load_tpl("coins.png")
        self.mailbox_heart_tpl = self._load_tpl("mailbox_heart.png") # New template for mailbox

        # Load End of List templates for the new logic
        self.end_list_templates = [
            self._load_tpl("end_of_fd_list.png"),
            self._load_tpl("end_of_fd_list_cn.png")
        ]

        # Load Close button variations
        self.close_templates = {
            "EN": self._load_tpl("close.png"),
            "CN": self._load_tpl("close_cn.png")
        }

    def _load_tpl(self, filename):
        """Helper to load images specifically from the resource folder."""
        full_path = os.path.join(self.res_path, filename)
        img = cv2.imread(full_path)
        if img is None:
            # We print a warning but don't exit to allow fallback logic
            print(f"⚠️ Warning: Could not find {full_path}")
        return img

    def find_template_center(self, target_img, template, threshold=0.8):
        """Finds the center of a template within an image."""
        if template is None: return []
        res = cv2.matchTemplate(target_img, template, cv2.TM_CCOEFF_NORMED)
        loc = np.where(res >= threshold)
        h, w = template.shape[:2]
        
        points = []
        for pt in zip(*loc[::-1]):
            cx, cy = int(pt[0] + w/2), int(pt[1] + h/2)
            # Group nearby points to avoid clicking the same object twice
            if not any(np.linalg.norm(np.array([cx, cy]) - np.array(p)) < 30 for p in points):
                points.append((cx, cy))
        return points

    def wait_and_tap_ok(self, timeout=5):
        """Polls the screen until the OK button appears, then taps it."""
        start_time = time.time()
        while time.time() - start_time < timeout:
            screenshot = self.device.screencap()
            frame = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
            
            ok_pts = self.find_template_center(frame, self.ok_tpl, threshold=0.85)
            if ok_pts:
                print(f"  👉 Tapping OK button at {ok_pts[0]}")
                self.executor.tap(ok_pts[0][0], ok_pts[0][1])
                return True
            time.sleep(0.5)
        return False

    def receive_present(self):
        print("🎁 Starting 'Receive Present' sequence...")
        
        # 1. Tap the Present/Mailbox icon
        self.executor.tap(615, 255)
        time.sleep(3.0) 
        
        if self.coin_tpl is None:
            print("  ❌ Error: 'coins.png' template missing in resource folder!")
            return
            
        h, w = self.coin_tpl.shape[:2]

        # --- RE-SCANNING LOOP ---
        while True:
            print("  🔍 Scanning for items to claim...")
            screenshot = self.device.screencap()
            screen = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
            
            target_x, target_y = None, None
            
            if self.receive_all:
                # NEW LOGIC: Scan for mailbox_heart.png
                heart_pts = self.find_template_center(screen, self.mailbox_heart_tpl, threshold=0.85)
                if heart_pts:
                    # Use fixed X coordinate 608 and Y from detected heart
                    target_x = 608
                    target_y = heart_pts[0][1]
                    print(f"  ✨ Found mailbox heart. Target tap: ({target_x}, {target_y})")
            else:
                # ORIGINAL LOGIC: Scan for coins.png
                if self.coin_tpl is not None:
                    h, w = self.coin_tpl.shape[:2]
                    res = cv2.matchTemplate(screen, self.coin_tpl, cv2.TM_CCOEFF_NORMED)
                    _, max_val, _, max_loc = cv2.minMaxLoc(res)
                    
                    if max_val >= 0.85:
                        target_x = max_loc[0] + 5
                        target_y = max_loc[1] + h - 5
                        print(f"  ✨ Found coin (Conf: {max_val:.2f}). Target tap: ({target_x}, {target_y})")

            # If no target found by either logic, exit loop
            if target_x is None:
                print("  ✅ No more claimable items detected.")
                break

            # Execute the tap based on whichever logic was chosen
            self.executor.tap(target_x, target_y)
            time.sleep(1.0)
            
            print("  Clicking OK")
            self.executor.tap(518, 737)
            time.sleep(1.0)
            
            print("  Dismissal taps for animations...")
            self.executor.tap(518, 737)
            time.sleep(1.0)
            
            # Optional: A tiny pause before the next scan to let the screen settle
            time.sleep(0.5)

        # 3. Finalize
        print("  Step 3: Closing mailbox using dynamic detection...")
        
        while True:
            # Capture fresh screen
            screenshot = self.device.screencap()
            screen = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
            
            found_button = False
            
            for lang, tpl in self.close_templates.items():
                if tpl is None: continue
                
                th, tw = tpl.shape[:2]
                res = cv2.matchTemplate(screen, tpl, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, max_loc = cv2.minMaxLoc(res)
                
                if max_val >= 0.85:
                    # Calculate middle position
                    center_x = max_loc[0] + (tw // 2)
                    center_y = max_loc[1] + (th // 2)
                    
                    print(f"  ✨ Found {lang} Close button (Conf: {max_val:.2f}). Tapping center: ({center_x}, {center_y})")
                    self.executor.tap(center_x, center_y)
                    found_button = True
                    break # Exit the language check to re-scan screen
            
            if not found_button:
                print("  ✅ No Close buttons detected. Mailbox should be closed.")
                break
            
            # Sleep 1 second before the next re-scan as requested
            time.sleep(1.0)
        print("✅ All present processing complete.")

    def refresh(self):
        time.sleep(1.5)
        self.executor.tap(28,660)
        time.sleep(1.5)
        self.executor.tap(28,757)

    def run(self):
        # 1. Start by going to the very top
        self.executor.scroll_to_top()
        time.sleep(3.0) 
        
        consecutive_no_hearts = 0
        hearts_sent_this_cycle = 0  # <--- NEW COUNTER
        
        while consecutive_no_hearts < 70:
            print("\n🔍 Scanning screen...")
              
            screenshot = self.device.screencap()
            frame = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
            
            # --- CONDITIONAL LOGIC BASED ON CONFIG ---
            if not self.send_to_all:
                # ORIGINAL LOGIC: Stop if zero marks detected
                zero_pts = self.find_template_center(frame, self.zero_tpl, threshold=0.95)
                if zero_pts:
                    print("🚫 Zero marks detected! Stopping cycle.")
                    break
            else:
                # NEW LOGIC: Look for End of List images to break
                found_end = False
                for tpl in self.end_list_templates:
                    if tpl is not None and self.find_template_center(frame, tpl, threshold=0.9):
                        found_end = True
                        break
                if found_end:
                    print("🔚 End of friend list reached! Stopping cycle.")
                    break

            hearts = self.find_template_center(frame, self.heart_tpl)
            
            if not hearts:
                print("📍 No hearts on this page. Scrolling down...")
                consecutive_no_hearts += 1
                self.executor.scroll_down()
                time.sleep(1.0) 
                continue

            consecutive_no_hearts = 0 
            print(f"✨ Found {len(hearts)} hearts.")
            
            for i, (x, y) in enumerate(hearts):
                print(f"[{i+1}/{len(hearts)}] Sending heart...")
                self.executor.tap(x, y)
                
                if self.wait_and_tap_ok():
                    hearts_sent_this_cycle += 1 # <--- INCREMENT
                    time.sleep(1.0)
                    self.executor.tap(540, 100) # Dismiss animation
                    time.sleep(0.5) 
                    self.executor.tap(540, 100) # Dismiss animation
                    time.sleep(0.5) 
                    
                    # --- TRIGGER RECEIVE PRESENT EVERY 10 HEARTS ---
                    if hearts_sent_this_cycle >= 10:
                        print(f"🎯 Milestone reached: {hearts_sent_this_cycle} hearts sent.")
                        self.receive_present()
                        hearts_sent_this_cycle = 0 # Reset counter
                        
                        # Re-capture screen because receive_present UI might have 
                        # shifted the list or changed the current view
                        screenshot = self.device.screencap()
                        frame = cv2.imdecode(np.frombuffer(screenshot, np.uint8), cv2.IMREAD_COLOR)
                else:
                    print("  ⚠️ OK button timed out.")

            print("📜 Moving to next page...")
            self.executor.scroll_down()
            time.sleep(1.0)
  
        print("✅ Finished: Heart sending complete.")
        self.refresh()
        time.sleep(3.0)

if __name__ == "__main__":
    sender = HeartSender(resource_folder="resource")
    
    # Track iterations to monitor long-term performance
    iteration = 1
    
    try:
        while True:
            print(f"\n🚀 --- Starting Cycle #{iteration} ---")
            # First check for presents that might be waiting
            sender.receive_present()
            # This calls the scanning logic and the subsequent receive/refresh
            sender.run()
            
            print(f"\n🔄 Cycle #{iteration} complete. Entering 10-minute maintenance mode...")
            # Loop 10 times (10 minutes total)
            for m in range(1, 11):
                print(f"  ⏳ Cooldown Minute {m}/10: Checking for presents...")
                sender.receive_present()
                
                # Sleep for 60 seconds unless it's the very last minute 
                # (to avoid an extra minute of waiting before the next cycle)
                if m < 10:
                    time.sleep(60.0)
            
            iteration += 1
            
    except KeyboardInterrupt:
        print("\n🛑 Script stopped by user.")
    except Exception as e:
        print(f"\n❌ A critical error occurred: {e}")
    finally:
        # This block ALWAYS runs, ensuring the terminal is released
        print("🧹 Cleaning up connections...")
        sender.executor.close()