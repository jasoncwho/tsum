import socket
import time
import subprocess

class SwipeExecutor:
    def __init__(self, device_id, port=1080):
        self.adb_path = r"C:\LDPlayer\LDPlayer9\adb.exe"
        self.device = device_id  # This must be the serial from 'adb devices'
        self.port = port
        self.socket = None
        self._setup_monkey()
        
    def _setup_monkey(self):
        print(f"🧹 Cleaning up {self.device} on port {self.port}...")
        try:
            # You MUST add "-s", self.device to every command
            subprocess.run([self.adb_path, "-s", self.device, "shell", "pkill", "-9", "monkey"], capture_output=True)
            
            # Remove existing forward for THIS port only
            subprocess.run([self.adb_path, "-s", self.device, "forward", "--remove", f"tcp:{self.port}"], capture_output=True)

            # Establish the new forward
            subprocess.run([self.adb_path, "-s", self.device, "forward", f"tcp:{self.port}", f"tcp:{self.port}"], check=True)
            
            # Start monkey on the specific device
            subprocess.Popen([self.adb_path, "-s", self.device, "shell", "monkey", "--port", str(self.port), "1"], 
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            time.sleep(2)
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect(("127.0.0.1", self.port))
            print(f"✨ {self.device} connection established on port {self.port}.")

        except Exception as e:
            print(f"❌ Setup failed for {self.device}: {e}")

    def _send(self, msg):
        if self.socket:
            try:
                self.socket.send(f"{msg}\n".encode('utf-8'))
                # If a timeout happens here, the VM is busy processing
                return self.socket.recv(128) 
            except socket.timeout:
                print(f"⏳ VM is busy... waiting for response to '{msg}'")
                # Try one more receive before giving up
                try:
                    return self.socket.recv(128)
                except:
                    return None
            except Exception as e:
                print(f"⚠️ Communication Error: {e}")
                self.socket = None

    def tap(self, x, y):
        """Basic tap command."""
        self._send(f"tap {int(x)} {int(y)}")

    def scroll_down(self):
        print("scroll down a little")
        # A simple straight-line chain for scrolling up
        # From bottom (800) to top (200)
        down_chain = [(360, 800), (360, 750)]
        
        #for i in range(50):
        #    print(f"  Step {i+1}/50")
        self.fast_swipe(down_chain,0)

    def scroll_to_top(self):
        print("🔝 Resetting to top of list...")
        # A simple straight-line chain for scrolling up
        # From bottom (800) to top (200)
        up_chain = [(360, 600), (360, 800)]
        
        for i in range(100):
            print(f"  Step {i+1}/100")
            self.fast_swipe(up_chain,0)


    def fast_swipe(self, chain, offset_y):
        if not chain: return
        
        # 1. Start
        x, y = chain[0]
        self._send(f"touch down {x} {y + offset_y}")

        # 2. Move
        for i in range(1, len(chain)):
            tx, ty = chain[i]
            self._send(f"touch move {tx} {ty + offset_y}")

        # 3. Release
        lx, ly = chain[-1]
        self._send(f"touch up {lx} {ly + offset_y}")

    def close(self):
        """Properly shuts down the server to fix terminal hang/backspace issues."""
        if self.socket:
            print("🔌 Shutting down Monkey server...")
            try:
                self._send("quit")
                self.socket.close()
                self.socket = None
                print("✅ Terminal released successfully.")
            except:
                pass